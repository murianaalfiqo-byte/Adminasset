<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Borrowing extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
        // Proteksi Akses Admin
        if ($this->session->userdata('role') !== 'admin') {
            $this->session->set_flashdata('error_msg', 'Anda tidak memiliki hak akses ke halaman ini!');
            redirect('auth');
        }
    }

    // Halaman Utama Kelola Peminjaman Aset
    public function index() {
        $data['title'] = 'Kelola Peminjaman Aset - AssetFlow';
        $data['user_name'] = $this->session->userdata('name');

        // Filter status dari URL (opsional)
        $status_filter = $this->input->get('status');

        $this->db->select('borrowings.*, users.name as user_name, users.email as user_email, assets.name as asset_name, assets.asset_code, assets.photo');
        $this->db->from('borrowings');
        $this->db->join('users', 'users.id = borrowings.user_id', 'left');
        $this->db->join('assets', 'assets.id = borrowings.asset_id', 'left');

        if (!empty($status_filter)) {
            $this->db->where('borrowings.status', $status_filter);
        }

        $this->db->order_by('borrowings.id', 'DESC');
        $data['borrowings'] = $this->db->get()->result_array();

        // Hitung Counter Status untuk Badge Tab
        $data['count_pending']  = $this->db->where('status', 'pending')->count_all_results('borrowings');
        $data['count_in_use']   = $this->db->where('status', 'in_use')->count_all_results('borrowings');
        $data['count_returned'] = $this->db->where('status', 'returned')->count_all_results('borrowings');
        $data['count_all']      = $this->db->count_all('borrowings');

        $this->load->view('admin/layout/header', $data);
        $this->load->view('admin/layout/sidebar', $data);
        $this->load->view('admin/layout/topbar', $data);
        $this->load->view('admin/borrowing/index', $data);
        $this->load->view('admin/layout/footer');
    }

    // Setujui Pengajuan Peminjaman
    public function approve($id) {
        $borrowing = $this->db->get_where('borrowings', ['id' => $id])->row_array();
        
        if ($borrowing) {
            // Update status peminjaman jadi 'approved'
            $this->db->where('id', $id);
            $this->db->update('borrowings', [
                'status' => 'approved',
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            $this->session->set_flashdata('success_msg', 'Pengajuan peminjaman berhasil disetujui!');
        } else {
            $this->session->set_flashdata('error_msg', 'Data peminjaman tidak ditemukan!');
        }

        redirect('borrowing');
    }

    // Tolak Pengajuan Peminjaman
    public function reject($id) {
        $borrowing = $this->db->get_where('borrowings', ['id' => $id])->row_array();

        if ($borrowing) {
            // Update status peminjaman jadi 'rejected'
            $this->db->where('id', $id);
            $this->db->update('borrowings', [
                'status' => 'rejected',
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            $this->session->set_flashdata('success_msg', 'Pengajuan peminjaman telah ditolak.');
        } else {
            $this->session->set_flashdata('error_msg', 'Data peminjaman tidak ditemukan!');
        }

        redirect('borrowing');
    }

    // Serahkan Barang ke Karyawan (In Use)
    public function handover($id) {
        $borrowing = $this->db->get_where('borrowings', ['id' => $id])->row_array();

        if ($borrowing) {
            // Update status peminjaman jadi 'in_use'
            $this->db->where('id', $id);
            $this->db->update('borrowings', [
                'status' => 'in_use',
                'actual_start_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            // Update status operasional aset jadi 'in_use'
            $this->db->where('id', $borrowing['asset_id']);
            $this->db->update('assets', ['operational_status' => 'in_use']);

            $this->session->set_flashdata('success_msg', 'Status barang diperbarui menjadi Sedang Dipinjam!');
        }

        redirect('borrowing');
    }

    // Proses Pengembalian Barang
    public function return_asset($id) {
        $borrowing = $this->db->get_where('borrowings', ['id' => $id])->row_array();

        if ($borrowing) {
            // Update status peminjaman jadi 'returned'
            $this->db->where('id', $id);
            $this->db->update('borrowings', [
                'status' => 'returned',
                'actual_end_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            // Kembalikan status operasional aset jadi 'available'
            $this->db->where('id', $borrowing['asset_id']);
            $this->db->update('assets', ['operational_status' => 'available']);

            $this->session->set_flashdata('success_msg', 'Barang berhasil dikembalikan ke inventaris.');
        }

        redirect('borrowing');
    }
}
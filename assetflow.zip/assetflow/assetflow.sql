-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for assetflow
CREATE DATABASE IF NOT EXISTS `assetflow` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `assetflow`;

-- Dumping structure for table assetflow.activity_logs
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.activity_logs: ~0 rows (approximately)

-- Dumping structure for table assetflow.assets
CREATE TABLE IF NOT EXISTS `assets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `category_id` int NOT NULL,
  `location_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `brand` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `model` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `serial_number` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT 'default_asset.png',
  `description` text COLLATE utf8mb4_general_ci,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(15,2) DEFAULT '0.00',
  `vendor` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `management_type` enum('borrowable','assignable','fixed') COLLATE utf8mb4_general_ci DEFAULT 'borrowable',
  `condition_status` enum('good','fair','damaged','lost') COLLATE utf8mb4_general_ci DEFAULT 'good',
  `operational_status` enum('available','in_use','assigned','maintenance','archived') COLLATE utf8mb4_general_ci DEFAULT 'available',
  `price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `is_archived` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `asset_code` (`asset_code`),
  UNIQUE KEY `serial_number` (`serial_number`),
  KEY `category_id` (`category_id`),
  KEY `location_id` (`location_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `assets_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assets_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.assets: ~4 rows (approximately)
INSERT INTO `assets` (`id`, `asset_code`, `name`, `category_id`, `location_id`, `department_id`, `brand`, `model`, `serial_number`, `photo`, `description`, `purchase_date`, `purchase_price`, `vendor`, `management_type`, `condition_status`, `operational_status`, `price`, `is_archived`, `created_at`, `updated_at`) VALUES
	(3, 'lap-02', 'lenovo thinkpad', 2, 1, 1, 'lenovo', 'thinkpad', '6356980', 'ASET-1791942357.png', NULL, '2026-10-16', 8.00, NULL, 'assignable', 'good', 'assigned', 0.00, 0, '2026-10-14 08:45:57', '2026-10-19 11:12:20'),
	(4, 'lap-03', 'macbook m2 pro 2020', 2, 1, 1, 'apple', 'm2 pro', '826187361', 'ASET-1792335397.PNG', NULL, NULL, 0.00, NULL, 'borrowable', 'good', 'available', 0.00, 0, '2026-10-15 09:35:55', '2026-10-20 11:26:33'),
	(5, 'lap-04', 'macbook m2 ', 2, 1, 1, 'apple', 'm2 ', '715813527', 'ASET-1792031953.png', NULL, '2024-02-15', 12000000.00, NULL, 'borrowable', 'good', 'in_use', 0.00, 0, '2026-10-15 09:39:13', '2026-10-15 09:41:32'),
	(7, 'lap-01', 'macbook m1 pro 2020', 2, 1, NULL, 'apple', 'm1 pro', '76843112300', 'ASET-1792335382.png', NULL, NULL, 0.00, NULL, 'borrowable', 'good', 'available', 0.00, 0, '2026-10-19 09:10:13', '2026-10-20 09:36:44'),
	(8, 'kP-05', 'iPAD', 2, 1, NULL, 'apple', 'ipad mini', '21351236151', 'ASET-1792383003.PNG', NULL, '2026-10-13', 8000000.00, NULL, 'borrowable', 'good', 'archived', 0.00, 1, '2026-10-19 11:10:03', '2026-10-19 11:10:15'),
	(9, 'kP-10', 'hebat', 3, NULL, NULL, '', '', '', 'default_asset.png', NULL, NULL, 8000000.00, NULL, 'borrowable', 'good', 'available', 0.00, 0, '2026-10-20 11:21:49', '2026-10-20 11:21:49'),
	(11, 'kP-19', 'afeaaw', 3, NULL, NULL, '', '', NULL, 'default_asset.png', NULL, NULL, 20000000.00, NULL, 'borrowable', 'good', 'available', 0.00, 0, '2026-10-20 11:24:32', '2026-10-20 11:24:32');

-- Dumping structure for table assetflow.asset_assignments
CREATE TABLE IF NOT EXISTS `asset_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL,
  `user_id` int NOT NULL,
  `assigned_by` int DEFAULT NULL,
  `assigned_at` datetime NOT NULL,
  `assigned_condition` enum('good','fair','damaged') COLLATE utf8mb4_general_ci NOT NULL,
  `assignment_note` text COLLATE utf8mb4_general_ci,
  `returned_at` datetime DEFAULT NULL,
  `return_condition` enum('good','fair','damaged','lost') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('active','returned') COLLATE utf8mb4_general_ci DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `user_id` (`user_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `asset_assignments_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  CONSTRAINT `asset_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.asset_assignments: ~0 rows (approximately)

-- Dumping structure for table assetflow.assignments
CREATE TABLE IF NOT EXISTS `assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL,
  `user_id` int NOT NULL,
  `assigned_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('assigned','returned') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'assigned',
  `notes` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.assignments: ~0 rows (approximately)
INSERT INTO `assignments` (`id`, `asset_id`, `user_id`, `assigned_date`, `return_date`, `status`, `notes`) VALUES
	(1, 3, 3, '2026-10-19', NULL, 'assigned', 'charger ddan tas');

-- Dumping structure for table assetflow.borrowings
CREATE TABLE IF NOT EXISTS `borrowings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `borrowing_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `asset_id` int NOT NULL,
  `user_id` int NOT NULL,
  `requested_start_at` datetime NOT NULL,
  `requested_end_at` datetime NOT NULL,
  `reason` text COLLATE utf8mb4_general_ci,
  `approved_by` int DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `actual_handover_at` datetime DEFAULT NULL,
  `handover_condition` enum('good','fair','damaged') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `actual_return_at` datetime DEFAULT NULL,
  `return_condition` enum('good','fair','damaged','lost') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `purpose` text COLLATE utf8mb4_general_ci NOT NULL,
  `admin_note` text COLLATE utf8mb4_general_ci,
  `status` enum('pending','approved','ready_for_handover','in_use','returned','rejected','canceled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `borrowing_code` (`borrowing_code`),
  KEY `asset_id` (`asset_id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `borrowings_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  CONSTRAINT `borrowings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `borrowings_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.borrowings: ~1 rows (approximately)
INSERT INTO `borrowings` (`id`, `borrowing_code`, `asset_id`, `user_id`, `requested_start_at`, `requested_end_at`, `reason`, `approved_by`, `approved_at`, `actual_handover_at`, `handover_condition`, `actual_return_at`, `return_condition`, `purpose`, `admin_note`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'BRW-20261015-2E47', 5, 3, '2026-10-16 09:40:00', '2026-10-18 09:40:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pinjemin kontol', NULL, 'in_use', '2026-10-15 09:40:57', '2026-10-15 09:42:50'),
	(2, 'TRX-20261018-AC36', 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'map', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 'canceled', '2026-10-18 22:28:23', '2026-10-19 11:15:52');

-- Dumping structure for table assetflow.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.categories: ~0 rows (approximately)
INSERT INTO `categories` (`id`, `name`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
	(2, 'elektronik', 'barang dengan kategori elektronik\r\n', 1, '2026-10-12 15:55:57', '2026-10-12 15:55:57'),
	(3, 'apaja', 'awoi', 1, '2026-10-19 11:10:55', '2026-10-19 11:10:55');

-- Dumping structure for table assetflow.departments
CREATE TABLE IF NOT EXISTS `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.departments: ~0 rows (approximately)
INSERT INTO `departments` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
	(1, 'IT Department', 'Departemen Teknologi Informasi', '2026-10-09 14:36:39', '2026-10-09 14:36:39'),
	(2, 'backend dev', 'apaa', '2026-10-19 11:11:35', '2026-10-19 11:11:35');

-- Dumping structure for table assetflow.locations
CREATE TABLE IF NOT EXISTS `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.locations: ~1 rows (approximately)
INSERT INTO `locations` (`id`, `name`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'rak elektronik lt 1', '', 1, '2026-10-13 09:02:03', '2026-10-13 09:02:03');

-- Dumping structure for table assetflow.maintenance_records
CREATE TABLE IF NOT EXISTS `maintenance_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL,
  `problem_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(15,2) DEFAULT '0.00',
  `status` enum('ongoing','completed') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'ongoing',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.maintenance_records: ~0 rows (approximately)
INSERT INTO `maintenance_records` (`id`, `asset_id`, `problem_description`, `start_date`, `end_date`, `cost`, `status`) VALUES
	(1, 1, 'asdasdasd', '2026-10-15', NULL, 0.00, 'ongoing'),
	(2, 7, 'lcd', '2026-10-19', '2026-10-20', 2000000.00, 'completed'),
	(3, 4, 'rusak', '2026-10-20', '2026-10-20', 2000000.00, 'completed');

-- Dumping structure for table assetflow.maintenance_schedules
CREATE TABLE IF NOT EXISTS `maintenance_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_id` int NOT NULL,
  `maintenance_type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `scheduled_at` date NOT NULL,
  `recurrence_interval` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vendor_or_technician` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `estimated_cost` decimal(15,2) DEFAULT '0.00',
  `status` enum('scheduled','completed','cancelled','missed') COLLATE utf8mb4_general_ci DEFAULT 'scheduled',
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  CONSTRAINT `maintenance_schedules_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.maintenance_schedules: ~0 rows (approximately)

-- Dumping structure for table assetflow.notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `related_id` int DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.notifications: ~0 rows (approximately)

-- Dumping structure for table assetflow.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table assetflow.password_resets: ~0 rows (approximately)

-- Dumping structure for table assetflow.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','employee') COLLATE utf8mb4_general_ci DEFAULT 'employee',
  `department_id` int DEFAULT NULL,
  `position` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `profile_photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT 'default.png',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_code` (`employee_code`),
  UNIQUE KEY `email` (`email`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table assetflow.users: ~2 rows (approximately)
INSERT INTO `users` (`id`, `employee_code`, `name`, `email`, `password_hash`, `role`, `department_id`, `position`, `phone`, `profile_photo`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'EMP-0001', 'Super Admin', 'admin@assetflow.com', '$2y$10$0f6hgntDHcELy9NlCc7aR.SYVy8A09v7rOY7tRD82VBDAbmmWGWFK', 'admin', 1, 'System Administrator', NULL, 'default.png', 1, '2026-10-09 14:36:40', '2026-10-12 09:18:02'),
	(3, 'emp=002', 'Destra Wijaya', 'destrajaya11@gmail.com', '$2y$10$le/ewdcG.5LrkwSoQ.czyOGxTm2hGFbVAnfX3OOgfqOv/GBcoNzRK', 'employee', 1, 'backend dev', '08954239870', 'default.png', 1, '2026-10-13 16:01:38', '2026-10-13 16:01:38'),
	(4, 'emp 3', 'ali', 'murianaalfiqo@gmail.com', '$2y$10$J6W8hne6825yawfY046reeHudVivlZOdQk2OQVw73sPxdl/JcrSai', 'employee', 2, 'beckend devekoper', '0888931231', 'default.png', 0, '2026-10-19 11:14:01', '2026-10-19 11:14:09');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
